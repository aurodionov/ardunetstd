package com.example.dima.iremote;

import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.String;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;


public class MainActivity extends AppCompatActivity {

    BalkonTask balkontask;
    TextView otvetardunet;
    EditText sendtoard, iport;
    final String FILENAME = "file";
    String ipadr;
    int ports;
    int portr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        otvetardunet = (TextView) findViewById(R.id.otvetardunet);
        sendtoard = (EditText) findViewById(R.id.sendtoard);
        iport = (EditText) findViewById(R.id.iport);
        readFile();

        balkontask = new BalkonTask();
        balkontask.execute();
    }

    @Override
    public void onBackPressed() {
        balkontask.cancel(true);
        System.exit(0);
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        balkontask.cancel(true);
        System.exit(0);
    }


    public void sendS(View v) {
        String to_rout = sendtoard.getText().toString();
        sendtoard.setText("");

        try {
            byte[] message = to_rout.getBytes();
            InetAddress address = InetAddress.getByName(ipadr);
            DatagramPacket packet = new DatagramPacket(message, message.length, address, ports);
            DatagramSocket dsocket = new DatagramSocket();
            dsocket.send(packet);
            dsocket.close();
        }

        catch (Exception e) {}
    }


    class BalkonTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... params) {

            Runnable runnable = new Runnable() {
                String lText = "0";

                public void run() {

                    while (true) {

                        try {
                            byte[] lMsg = new byte[128];
                            DatagramPacket dp = new DatagramPacket(lMsg, lMsg.length);
                            DatagramSocket ds = null;
                            try {
                                ds = new DatagramSocket(portr);
                                ds.receive(dp);
                                lText = new String(lMsg, 0, dp.getLength());

                            } catch (SocketException e) {
                                e.printStackTrace();
                            } finally {
                                if (ds != null) {
                                    ds.close();
                                }
                            }

                        } catch (Exception e) {}

                        runOnUiThread(new Runnable() { //// BalkonTask

                            @Override
                            public void run() {
                                otvetardunet.setText(lText);
                            }
                        });

                    }
                }
            };
            Thread thread = new Thread(runnable);
            thread.start();

            return null;
        }
    }


     public void readFile() {
        String read_from_file;

        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(openFileInput(FILENAME)));

            if((read_from_file = br.readLine()) != null) {

                String[] paket = read_from_file.split(" ");
                if(paket.length == 3) {
                    ipadr = paket[0];
                    ports = Integer.parseInt(paket[1]);
                    portr = Integer.parseInt(paket[2]);
                    Toast.makeText(MainActivity.this, read_from_file, Toast.LENGTH_LONG).show();
                }

                else {
                    Toast.makeText(MainActivity.this, "Файл не корректный " + read_from_file, Toast.LENGTH_LONG).show();
                }
            }

            else {
                Toast.makeText(MainActivity.this, "Файл пустой", Toast.LENGTH_LONG).show();
            }

        } catch (IOException e) {
            Toast.makeText(MainActivity.this, "Нету файла", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }


    public void writeFile(View v) {
            String write_to_file = iport.getText().toString();
            iport.setText("");
            Toast.makeText(MainActivity.this, write_to_file, Toast.LENGTH_LONG).show();

            try {
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(openFileOutput(FILENAME, MODE_PRIVATE)));
                bw.write(write_to_file);
                bw.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
    }
} // END MainActivity



